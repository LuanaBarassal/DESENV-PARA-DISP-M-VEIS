package br.unisanta.cadastrolivro.model

data class Livro(
    val tituloLivro:String,
    val autorLivro:String
)