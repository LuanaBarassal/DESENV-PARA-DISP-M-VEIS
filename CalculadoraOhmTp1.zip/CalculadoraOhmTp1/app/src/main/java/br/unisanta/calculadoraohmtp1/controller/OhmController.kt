package br.unisanta.calculadoraohmtp1.controller

import br.unisanta.calculadoraohmtp1.model.OhmModel

class OhmController {
    private val model = OhmModel()

    fun calcularTensao(r: Double?, i: Double?): Double? {
        if (r == null || i == null) return null
        return model.calcularTensao(r, i)
    }

    fun formatarNumero(num: Double): String {
        return if (num % 1.0 == 0.0) {
            num.toInt().toString()
        } else {
            "%.2f".format(num)
        }
    }
}