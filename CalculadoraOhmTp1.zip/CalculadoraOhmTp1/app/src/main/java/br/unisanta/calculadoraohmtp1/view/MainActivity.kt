package br.unisanta.calculadoraohmtp1.view

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import br.unisanta.calculadoraohmtp1.R
import br.unisanta.calculadoraohmtp1.controller.OhmController

class MainActivity : AppCompatActivity() {
    private val controller = OhmController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etResistencia = findViewById<EditText>(R.id.editResistencia)
        val etCorrente = findViewById<EditText>(R.id.editCorrente)
        val tvResultado = findViewById<TextView>(R.id.textResultado)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)

        fun calcular() {
            val r = etResistencia.text.toString().toDoubleOrNull()
            val i = etCorrente.text.toString().toDoubleOrNull()

            val resultado = controller.calcularTensao(r, i)
            tvResultado.text = if (resultado != null) {
                "Tensão (V): ${controller.formatarNumero(resultado)} V"
            } else {
                "Entrada inválida"
            }
        }

        btnCalcular.setOnClickListener { calcular() }
    }
}