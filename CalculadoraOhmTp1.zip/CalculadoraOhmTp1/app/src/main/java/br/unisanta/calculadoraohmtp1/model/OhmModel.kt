package br.unisanta.calculadoraohmtp1.model

class OhmModel {
    fun calcularTensao(resistencia: Double, corrente: Double): Double {
        return resistencia * corrente
    }
}