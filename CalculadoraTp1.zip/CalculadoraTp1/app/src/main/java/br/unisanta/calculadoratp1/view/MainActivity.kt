package br.unisanta.calculadoratp1.view

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import br.unisanta.calculadoratp1.R
import br.unisanta.calculadoratp1.controller.CalculadoraController

class MainActivity : AppCompatActivity() {

    private val controller = CalculadoraController()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNumero1 = findViewById<EditText>(R.id.editNumero1)
        val etNumero2 = findViewById<EditText>(R.id.editNumero2)
        val tvResultado = findViewById<TextView>(R.id.textResultado)

        fun calcular(operador: Char) {
            val n1 = etNumero1.text.toString().toDoubleOrNull()
            val n2 = etNumero2.text.toString().toDoubleOrNull()
            val resultado = controller.realizarCalculo(n1, n2, operador)
            tvResultado.text = resultado
        }

        findViewById<Button>(R.id.btnSoma).setOnClickListener { calcular('+') }
        findViewById<Button>(R.id.btnSubtrai).setOnClickListener { calcular('-') }
        findViewById<Button>(R.id.btnMultiplica).setOnClickListener { calcular('*') }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { calcular('/') }
    }
}
