package br.unisanta.calculadoratp1.controller

import br.unisanta.calculadoratp1.model.CalculadoraModel

class CalculadoraController {

    private val model = CalculadoraModel()

    fun realizarCalculo(n1: Double?, n2: Double?, operador: Char): String {
        if (n1 == null || n2 == null) {
            return "Valores inválidos"
        }

        val resultado = model.calcular(n1, n2, operador)
        return if (resultado.isNaN()) {
            "Erro na operação"
        } else {
            val textoFormatado = if (resultado % 1.0 == 0.0) resultado.toInt().toString() else "%.2f".format(resultado)
            "Resultado: $textoFormatado"
        }
    }

}