package br.unisanta.calculadoratp1.model

class CalculadoraModel {
    fun calcular(a: Double, b: Double, operador: Char): Double {
        return when (operador) {
            '+' -> a + b
            '-' -> a - b
            '*' -> a * b
            '/' -> if (b != 0.0) a / b else Double.NaN
            else -> Double.NaN
        }
    }
}
